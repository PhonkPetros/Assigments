﻿using System;

namespace assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[2-3] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            HangmanGame hangman = new HangmanGame();
            List<string> words = ListOfWords(filename);
            hangman.secretWord = SelectWord(words);
            hangman.Init(hangman.secretWord);
            Console.WriteLine($"The secret word is: {hangman.secretWord}");
            if (PlayHangman(hangman))
            {
                Console.WriteLine("You guessed the word!");
            }
            else
            {
                Console.WriteLine($"Too bad, you did not guess the word ({hangman.secretWord})");
            }
        }
        List<String> ListOfWords(string filename)
        {

            List<String> list = new List<String>();

            string line;

            System.IO.StreamReader file = new System.IO.StreamReader(filename);
            while ((line = file.ReadLine()) != null)
            {
                if (line.Length >= 3)
                {
                    list.Add(line);
                }
            }

            file.Close();
            return list;
        }
        string SelectWord(List<String> words)
        {
            Random random = new Random();

            return words[random.Next(0, words.Count)];
        }
        bool PlayHangman(HangmanGame hangman)
        {
            int nrOfAttempts = 8;
            char userEnteredLetter;
            List<char> enteredLetters = new List<char>();
            List<char> blacklist = new List<char>();
            blacklist.Add(' ');

            DisplayWord(hangman.guessedWord);
            while (!hangman.IsGuessed() && nrOfAttempts > 0)
            {
                userEnteredLetter = ReadLetter(blacklist);
                enteredLetters.Add(userEnteredLetter);
                blacklist.Add(userEnteredLetter);
                DisplayLetters(enteredLetters);
                if (hangman.ContainsLetter(userEnteredLetter))
                {
                    hangman.ProcessLetter(userEnteredLetter);
                }
                else
                {
                    nrOfAttempts--;
                }
                Console.WriteLine($"\nAttempts left: {nrOfAttempts}");
                Console.WriteLine();
                DisplayWord(hangman.guessedWord);
            }
            return hangman.IsGuessed();
        }
        static void DisplayWord(string word)
        {
            foreach (char leter in word)
            {
                Console.Write($"{leter} ");
            }
            Console.WriteLine();
        }
        void DisplayLetters(List<char> letters)
        {
            Console.Write("Entered letters: ");
            foreach (char word in letters)
                Console.Write($"{word} ");
        }
        char ReadLetter(List<char> blacklistLetters)
        {
            char letter;
            while (true)
            {
                Console.Write("Enter a letter: ");
                letter = char.Parse(Console.ReadLine());
                if (!blacklistLetters.Contains(letter))
                {
                    break;
                }
            }
            return letter;
        }
    }
}
