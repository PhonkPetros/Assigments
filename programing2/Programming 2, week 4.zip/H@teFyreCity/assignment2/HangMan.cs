﻿namespace assignment2
{
    internal class HangmanGame
    {
        public string secretWord;
        public string guessedWord;

        public void Init(string secretWord)
        {
            guessedWord = "";
            for (int i = 0; i < secretWord.Length; i++)
            {
                guessedWord += ".";
            }
        }
        public bool ContainsLetter(char letter)
        {
            if (secretWord.Contains(letter))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void ProcessLetter(char letter)
        {
            string newGuessedWord = "";
            for (int i = 0; i < guessedWord.Length; i++)
            {
                if (letter == secretWord[i])
                {
                    newGuessedWord += letter;
                }
                else
                {
                    newGuessedWord += guessedWord[i];
                }
            }
            guessedWord = newGuessedWord;
        }

        public bool IsGuessed()
        {
            if (secretWord == guessedWord)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}