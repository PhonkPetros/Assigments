﻿using System;

namespace assignment1
{
    internal class Program
    {
        public static Person ReadPerson()
        {
            Person person = new Person();
            Console.Write("Enter your name: ");
            person.Name = Console.ReadLine();
            Console.Write("Enter your city: ");
            person.City = Console.ReadLine();
            Console.Write("Enter your age: ");
            person.Age = int.Parse(Console.ReadLine());
            return person;
        }
        public static Person ReadPerson(string filename)
        {
            Person person = new Person();
            StreamReader reader = new StreamReader(filename);
            person.Name = reader.ReadLine();
            person.City = reader.ReadLine();
            person.Age = int.Parse(reader.ReadLine());
            reader.Close();
            return person;
        }

        public static void DisplayPerson(Person person)
        {
            Console.WriteLine($"Name: {person.Name}");
            Console.WriteLine($"City: {person.City}");
            Console.WriteLine($"Age: {person.Age}");
        }


        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();

            Person person = new Person();

            if (File.Exists("test.txt"))
            {
                person = ReadPerson("test.txt");
                if (person.Name.Contains(name))
                {
                    Console.WriteLine($"Nice to see you again, {person.Name}!\nWe have the following information about you:");
                    DisplayPerson(person);
                    return;
                }
            }
            Console.WriteLine($"Welcome {name}");
            person = ReadPerson();
            WritePerson(person, "test.txt");
            Console.WriteLine("Your data is written to file.");

        }

        public static void WritePerson(Person person, string filename)
        {
            StreamWriter writer = new StreamWriter(filename);
            writer.WriteLine(person.Name);
            writer.WriteLine(person.City);
            writer.WriteLine(person.Age);
            writer.Close();
        }
    }
}