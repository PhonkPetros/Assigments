﻿namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[2-3] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            Console.Write("Enter a word (to search): ");
            string word = Console.ReadLine();
            Console.WriteLine();

            int count = SearchWordInFile(filename, word);

            Console.WriteLine();
            Console.WriteLine($"Number of lines containing the word: {count}");
        }

        bool WordInLine(string line, string word)
        {
            return line.Contains(word, StringComparison.OrdinalIgnoreCase);
        }

        int SearchWordInFile(string filename, string word)
        {
            int count = 0;

            using (StreamReader reader = new StreamReader(filename))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.IndexOf(word, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        DisplayWordInLine(line, word);
                        count++;
                    }
                }
            }

            return count;
        }

        void DisplayWordInLine(string line, string word)
        {
            int index = line.IndexOf(word, StringComparison.OrdinalIgnoreCase);

            Console.Write(line.Substring(0, index));

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"[{line.Substring(index, word.Length)}]");
            Console.ResetColor();

            Console.WriteLine(line.Substring(index + word.Length));
        }
    }
}