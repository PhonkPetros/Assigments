﻿namespace assignment1
{
    internal class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void PrintMonth(Month month)
        {
            Console.WriteLine(month.ToString());
        }

        void PrintMonths()
        {
            int counter = 1;
            for (Month month = Month.January; month <= Month.December; month++)
            {
                Console.Write($"{counter}. ");
                PrintMonth(month);
                counter++;
            }
        }

        Month ReadMonth(string question)
        {
            Console.Write(question);
            Month month = (Month)int.Parse(Console.ReadLine());

            while (Enum.IsDefined(typeof(Month), month) == false)
            {
                Console.WriteLine($"{month} is not a valid value. ");
                Console.Write(question);
                month = (Month)int.Parse(Console.ReadLine());
            }
            Console.Write($"{(int)month} => ");
            return month;
        }

        void Start()
        {
            PrintMonths();
            Console.WriteLine("");
            PrintMonth(ReadMonth("Enter a month number: "));
        }
    }
}