﻿using System;
using System.Security.Cryptography;

namespace assignment2
{
    internal class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        void Start()
        {
            Person[] people = new Person[3];

            for (int i = 0; i < 3; i++)
            {
                people[i] = ReadPerson();
                Console.WriteLine();
            }

            for (int j = 0; j < 3; j++)
            {
                PrintPerson(people[j]);
                Console.WriteLine();
            }


        }

        Person ReadPerson()
        {
            Person person = new Person();

            person.FirstName = ReadFirstName("Enter first name: ");
            person.LastName = ReadLastName("Enter last name: ");
            person.Gender = GenderReader("Enter gender (m/f): ");
            person.Age = ReadInt("Enter your age: ");
            person.City = ReadCity("Enter city: ");

            return person;

        }
        string ReadFirstName(string question)
        {
            Console.Write(question);
            string name = Console.ReadLine();
            return name;
        }

        string ReadLastName(string question)
        {
            Console.Write(question);
            string name = Console.ReadLine();
            return name;
        }
        int ReadInt(string question)
        {
            Console.Write(question);
            int age = int.Parse(Console.ReadLine());
            return age;
        }

        string ReadCity(string question)
        {
            Console.Write(question);
            string city = Console.ReadLine();
            return city;
        }

        GenderType GenderReader(string question)
        {
            Console.Write(question);
            string genderInput = Console.ReadLine();

            GenderType type;

            while (genderInput != "m" || genderInput != "f")
            {
                if (genderInput == "m" || genderInput == "f")
                {
                    break;
                }

                Console.Write(question);
                genderInput = Console.ReadLine();

            }
            if (genderInput == "m")
            {
                type = GenderType.Male;
                return type;
            }
            else
            {
                type = GenderType.Female;
                return type;
            }
        }

        void GenderPrinter(GenderType type)
        {
            if (type == GenderType.Male)
            {
                Console.WriteLine("(m)");
            }
            else
            {
                Console.WriteLine("(f)");
            }
        }
        void PrintPerson(Person p)
        {
            Console.Write($"{p.FirstName} {p.LastName} ");
            GenderPrinter(p.Gender);
            Console.WriteLine($"{p.Age} years old, {p.City}");
        }
    }
}