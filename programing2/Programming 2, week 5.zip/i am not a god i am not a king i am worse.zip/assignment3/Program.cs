﻿namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[3-4] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            Dictionary<string, string> words = ReadWords(filename);
            TranslateWords(words);
        }

        Dictionary<string, string> ReadWords(string filename)
        {
            Dictionary<string, string> words = new Dictionary<string, string>();

            string[] lines = File.ReadAllLines(filename);

            foreach (string line in lines)
            {
                string[] fields = line.Split(';');
                string dutchWord = fields[0];
                string englishTranslation = fields[1];

                words.Add(dutchWord, englishTranslation);
            }

            return words;
        }

        void TranslateWords(Dictionary<string, string> words)
        {
            while (true)
            {
                Console.Write("Enter a word: ");
                string dutchWord = Console.ReadLine();

                if (dutchWord == "stop")
                {
                    break;
                }
                else if (dutchWord == "listall")
                {
                    ListAllWords(words);
                    continue;
                }
                else if (words.ContainsKey(dutchWord))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"{dutchWord} => {words[dutchWord]}");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine($"Word '{dutchWord}' not found");
                }
            }
        }

        void ListAllWords(Dictionary<string, string> words)
        {
            foreach (KeyValuePair<string, string> word in words)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"{word.Key} => {word.Value}");
                Console.ResetColor();
            }
        }
    }
}
