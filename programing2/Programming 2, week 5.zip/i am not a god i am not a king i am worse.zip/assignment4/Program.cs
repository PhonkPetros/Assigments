﻿namespace assignment4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[3-4] <filename>");
                return;
            }
            string filename = args[0];
            Program myProgram = new Program();
            myProgram.Start(filename);
        }
        void Start(string filename)
        {
            string[] words = ReadWords(filename);

            string secretWord = SelectWord(words);

            PlayLingo(secretWord);
        }

        public string[] ReadWords(string filename)
        {
            string[] lines = File.ReadAllLines(filename);

            return lines;
        }

        public string SelectWord(string[] words)
        {
            Random random = new Random();

            int index = random.Next(words.Length);

            return words[index];
        }

        static void PlayLingo(string secretWord)
        {
            int attemptsLeft = 4;
            int count = 2;
            Console.Write($"Enter a (5-letter) word, attempt 1: ");
            string wordInput = Console.ReadLine();
            string word = wordInput.ToUpper();

            while (attemptsLeft > 0 && secretWord != word)
            {

                for (int i = 0; i < word.Length; i++)
                {
                    bool letterIsCorrect = secretWord[i] == word[i];
                    bool letterIsInWrongPosition = secretWord.Contains(word[i]) && !letterIsCorrect;

                    if (letterIsCorrect)
                    {
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.Write(word[i]);
                    }
                    else if (letterIsInWrongPosition)
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.Write(word[i]);
                    }
                    else
                    {
                        Console.Write(word[i]);
                    }
                    Console.ResetColor();
                }
                Console.WriteLine();

                Console.Write($"Enter a (5-letter) word, attempt {count}: ");
                wordInput = Console.ReadLine();
                word = wordInput.ToUpper();

                attemptsLeft--;
                count++;
            }
            if (attemptsLeft == 0)
            {
                Console.WriteLine();
                Console.WriteLine($"Too bad, you did not guess the word ({secretWord})");
            }
            else if (word == secretWord)
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.WriteLine(secretWord);
                Console.ResetColor();
                Console.WriteLine("You have guessed the word!");
            }
        }
    }
}