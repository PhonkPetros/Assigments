﻿namespace CandyCrushLogic
{
    public class CandyCrusher
    {
        public static bool ScoreRowPresent(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                int counter = 1;

                for (int j = 1; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] == matrix[i, j - 1])
                    {
                        counter++;
                        if (counter == 3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                    }
                }
            }
            return false;
        }

        public static bool ScoreColumnPresent(int[,] matrix)
        {

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                int counter = 1;
                for (int j = 1; j < matrix.GetLength(1); j++)
                {
                    if (matrix[j, i] == matrix[j - 1, i])
                    {
                        counter++;
                        if (counter == 3)
                        {
                            return true;

                        }
                    }
                    else
                    {
                        counter = 1;

                    }
                }
            }
            return false;
        }
    }
}