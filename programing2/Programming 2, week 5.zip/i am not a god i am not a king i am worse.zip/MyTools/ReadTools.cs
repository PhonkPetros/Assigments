﻿namespace MyTools
{
    public class ReadTools
    {
        public static int ReadInt(string question)
        {
            Console.Write(question);
            int value = int.Parse(Console.ReadLine());
            return value;
        }

        public static int ReadInt(string question, int min, int max)
        {
            Console.Write(question);
            int age = int.Parse(Console.ReadLine());
            while (age < min || age > max)
            {
                Console.Write("How old are you? ");
                age = int.Parse(Console.ReadLine());
            }
            return age;
        }

        public static string ReadString(string question)
        {
            Console.Write(question);
            string name = Console.ReadLine();
            return name;
        }
    }

}