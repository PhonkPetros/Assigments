﻿namespace assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a letter");
            string first = Console.ReadLine();
            Console.WriteLine("Enter a letter");
            string second = Console.ReadLine();

            string third = first + second;

            if (third == "tr")
            {
                Console.WriteLine("Entered letters: t r a e i n s k o \r\nattempts left: 6\r\ntrainstation\r\nyou guessed the word");
            }
            else
            {
                Console.WriteLine("Entered letters: t x y z a e i o u b h g\r\nattempts left: 0\r\nt . a i . . t a t i o . \r\nToo bad, you did not guess the word (trainstation)");
            }
        }
    }
}