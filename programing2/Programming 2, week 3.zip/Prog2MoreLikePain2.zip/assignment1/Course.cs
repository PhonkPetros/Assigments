﻿namespace assignment1
{
    public class Course
    {
        public string Name;
        public int TheoryGrade;
        private PracticalGrade practicalGrade;

        internal PracticalGrade PracticalGrade { get => practicalGrade; set => practicalGrade = value; } //can't explain this but it works XD

        public bool Passed(Course course)
        {
            if (course.TheoryGrade >= 55 && (course.PracticalGrade == PracticalGrade.Sufficient || course.PracticalGrade == PracticalGrade.Good))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool CumLaude(Course course)
        {
            if(course.TheoryGrade >= 80 && course.PracticalGrade == PracticalGrade.Good)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
