﻿using System;
using System.Diagnostics;
using System.Diagnostics.Contracts;

namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        public PracticalGrade ReadPracticalGrade(string question)
        {
            PracticalGrade practicalGrade = new PracticalGrade();
            Course course = new Course();
            Console.Write(question);
            int grade = int.Parse(Console.ReadLine());

            if (grade == 0)
            {
                practicalGrade = PracticalGrade.None;
            }
            else if (grade == 1)
            {
                practicalGrade = PracticalGrade.Absent;
            }
            else if (grade == 2)
            {
                practicalGrade = PracticalGrade.Insufficient;
            }
            else if (grade == 3)
            {
                practicalGrade = PracticalGrade.Sufficient;
            }
            else if (grade == 4)
            {
                practicalGrade = PracticalGrade.Good;
            }
            return practicalGrade;
        }

        void DisplayCourse(Course course)
        {
            Console.WriteLine(course.Name);
            Console.WriteLine(course.TheoryGrade);
            Console.WriteLine(course.PracticalGrade);
        }

        Course ReadCourse(string question)
        {
            Course course = new Course();

            Console.Write(question);
            course.Name = Console.ReadLine();
            return course;

        }
        int ReadInt(string question)
        {
            Course course = new Course();
            Console.Write(question);
            course.TheoryGrade = int.Parse(Console.ReadLine());
            return course.TheoryGrade;

        }
        void Start()
        {
            List<Course> gradeList = ReadGradeList(3);

            /*Console.WriteLine("Enter a course.");

            Course course = ReadCourse("Name of the course: ");

            course.TheoryGrade = ReadInt($"Theorey grade for {course.Name}: ");

            Console.WriteLine("0.None, 1.Absent, 2.Insufficient, 3.Sufficien, 4.Good");
            course.PracticalGrade = ReadPracticalGrade($"Practical grade for {course.Name} ");

            DisplayCourse(course);*/

            DisplayGradeList(gradeList);
        }

        List<Course> ReadGradeList(int nrOfCourses)
        {
            Course course = new Course();
            List<Course> gradeList = new List<Course>();

            for (int i = 0; i < nrOfCourses; i++)
            {
                Console.WriteLine("Enter a course.");
                course = ReadCourse("Name of the course. ");
                course.TheoryGrade = ReadInt($"Theorey grade for {course.Name}: ");
                Console.WriteLine("0.None, 1.Absent, 2.Insufficient, 3.Sufficien, 4.Good");
                course.PracticalGrade = ReadPracticalGrade($"Practical grade for {course.Name}: ");
                gradeList.Add(course);
                Console.WriteLine();
            }
            return gradeList;
        }
        void DisplayGradeList(List<Course> gradeList)
        {
            int retake = 0;
            int pass = 0;
            int cumLude = 0;
            foreach (Course course in gradeList)
            {
                Console.WriteLine($"{course.Name}  : {course.TheoryGrade} {course.PracticalGrade}");

                if (course.CumLaude(course))
                {
                    cumLude++;
                }
                else if (course.Passed(course))
                {
                    pass++;
                }
                else
                {
                    retake++;
                }
            }

            if (retake > 0)
            {
                Console.WriteLine($"Too bad, you did not graduate, you got {retake} retakes");
            }
            else if (pass > 0)
            {
                Console.WriteLine("Congratulations, you graduated!");
            }
            else if(cumLude > 0)
            {
                Console.WriteLine("Congratulations, you graduated Cum Laude!");
            }
        }
    }
}