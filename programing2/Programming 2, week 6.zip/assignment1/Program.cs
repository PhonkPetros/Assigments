﻿using System.Runtime.ExceptionServices;

namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ChessPiece[,] board = new ChessPiece[8, 8];

            InitChessboard(board);

            DisplayChessboard(board);

            PlayChess(board);
        }

        static void InitChessboard(ChessPiece[,] chessboard)
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    chessboard[i, j] = null;
                }
                PutChessPieces(chessboard);
            }
        }

        static void DisplayChessboard(ChessPiece[,] chessboard)
        {
            for (int i = 0; i < chessboard.GetLength(0); i++)
            {
                Console.Write(8 - i + " ");

                for (int j = 0; j < chessboard.GetLength(1); j++)
                {
                    if ((i + j) % 2 == 0)
                        Console.BackgroundColor = ConsoleColor.Gray;
                    else
                        Console.BackgroundColor = ConsoleColor.DarkYellow;
                    DisplayChessPiece(chessboard[i, j]);
                    Console.Write("   ");
                    Console.ResetColor();
                }
                Console.WriteLine();
            }
            Console.Write("    ");
            for (int i = 0; i < chessboard.GetLength(0); i++)
            {
                Console.Write($"{(char)('A' + i)}     ");
            }
        }

        static void PutChessPieces(ChessPiece[,] chessboard)
        {
            ChessPieceType[] order =
            {
                ChessPieceType.Rook, ChessPieceType.Knight, ChessPieceType.Bishop, ChessPieceType.Queen, //the layout of the chesspieces 

                ChessPieceType.King, ChessPieceType.Bishop, ChessPieceType.Knight, ChessPieceType.Rook
            };
            for (int column = 0; column < chessboard.GetLength(1); column++)
            {
                chessboard[1, column] = new ChessPiece
                {
                    type = ChessPieceType.Pawn,
                    color = ChessPieceColor.black
                };

                chessboard[6, column] = new ChessPiece
                {
                    type = ChessPieceType.Pawn,
                    color = ChessPieceColor.white
                };

                chessboard[0, column] = new ChessPiece
                {
                    type = order[column],
                    color = ChessPieceColor.black
                };
                chessboard[7, column] = new ChessPiece
                {
                    type = order[column],
                    color = ChessPieceColor.white
                };
            }
        }
        static void DisplayChessPiece(ChessPiece chessPiece)
        {
            if (chessPiece == null)
            {
                Console.Write("   ");
                return;
            }

            if (chessPiece.color == ChessPieceColor.white)
            {
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Black;
            }
            string symbol = "";

            switch (chessPiece.type) //could be done with if and else if but it gets anyoing
            {
                case ChessPieceType.Pawn:
                    symbol = "p";
                    break;
                case ChessPieceType.Rook:
                    symbol = "r";
                    break;
                case ChessPieceType.Knight:
                    symbol = "k";
                    break;
                case ChessPieceType.Bishop:
                    symbol = "b";
                    break;
                case ChessPieceType.King:
                    symbol = "K";
                    break;
                case ChessPieceType.Queen:
                    symbol = "Q";
                    break;
            }
            Console.Write($" {symbol} ");
        }

        static Position String2Position(string pos)
        {
            Position position = new Position();

            int column = pos[0] - 'a';
            int row = 8 - int.Parse(pos[1].ToString());


            if (pos.Length != 2 || !char.IsLetter(pos[0]) || !char.IsDigit(pos[1]))
            {
                return null;
            }
            else if (column < 0 || column > 7 || row < 0 || row > 7)
            {
                return null;
            }

            position.fieldRow = row;
            position.fieldCol = column;

            return position;
        }

        static void PlayChess(ChessPiece[,] chessboard)
        {
            bool chessMove = true;

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("Enter move (e.g. a2 a3): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "stop")
                {
                    break;
                }

                string[] move = input.Split(' ');

                Position from = String2Position(move[0]);
                Position to = String2Position(move[1]);

                if (move.Length != 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid move format");
                    Console.ResetColor();
                }
                else if (from == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Invalid position: {move[0]}");
                    Console.ResetColor();
                }
                else if (to == null)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Invalid position: {move[1]}");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine("move from " + move[0] + " to " + move[1]);
                    if (CheckMove(chessboard, from, to) == true)
                    {
                        DoMove(chessboard, from, to);
                        Console.WriteLine();
                        DisplayChessboard(chessboard);
                    } 
                }
            }
        }

        static void DoMove(ChessPiece[,] chessboard, Position from, Position to)
        {
            chessboard[to.fieldRow, to.fieldCol] = chessboard[from.fieldRow, from.fieldCol];
            chessboard[from.fieldRow, from.fieldCol] = null;
        }

        static bool CheckMove(ChessPiece[,] chessboard, Position from, Position to)
        {

            if (chessboard[from.fieldRow, from.fieldCol] == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("No chess piece at from-position");
                Console.ResetColor();
                return false;
            }
            else if (chessboard[to.fieldRow, to.fieldCol] != null && chessboard[to.fieldRow, to.fieldCol].color == chessboard[from.fieldRow, from.fieldCol].color)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Can not take a chess piece of same color");
                Console.ResetColor();
                return false;
            }

            int hor = Math.Abs(from.fieldCol - to.fieldCol);
            int ver = Math.Abs(from.fieldRow - to.fieldRow);

            switch (chessboard[from.fieldRow, from.fieldCol].type)
            {
                case ChessPieceType.Rook:
                    if (hor * ver != 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid move for chess piece Rook");
                        Console.ResetColor();
                        return false;
                    }
                    break;
                case ChessPieceType.Knight:
                    if (hor * ver != 2)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid move for chess piece Knight");
                        Console.ResetColor();
                        return  false;
                    }
                    break;
                case ChessPieceType.Bishop:
                    if (hor != ver)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid move for chess piece Bishop");
                        Console.ResetColor();
                        return  false;
                    }
                    break;
                case ChessPieceType.King: //also can be done with if and else if but it.
                    if (hor != 1 && ver != 1)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid move for chess piece King");
                        Console.ResetColor();
                        return  false;
                    }
                    break;
                case ChessPieceType.Queen:
                    if (hor * ver != 0 && hor != ver)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid move for chess piece Queen");
                        Console.ResetColor();
                        return false;
                    }
                    break;
                case ChessPieceType.Pawn:
                    if (hor != 0 || ver != 1)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid move for chess piece Pawn");
                        Console.ResetColor();
                        return false;
                    }
                    break;

            }
            return true;
        }
    }
}