﻿using System.Runtime.ExceptionServices;

namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ChessPiece[,] board = new ChessPiece[8, 8];

            InitChessboard(board);

            DisplayChessboard(board);

            PlayChess(board);
        }

        static void InitChessboard(ChessPiece[,] chessboard)
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    chessboard[i, j] = null;
                }
                PutChessPieces(chessboard);
            }
        }

        static void DisplayChessboard(ChessPiece[,] chessboard)
        {
            for (int i = 0; i < chessboard.GetLength(0); i++)
            {
                Console.Write(8 - i + " ");

                for (int j = 0; j < chessboard.GetLength(1); j++)
                {
                    if ((i + j) % 2 == 0)
                        Console.BackgroundColor = ConsoleColor.Gray;
                    else
                        Console.BackgroundColor = ConsoleColor.DarkYellow;
                    DisplayChessPiece(chessboard[i, j]);
                    Console.Write("   ");
                    Console.ResetColor();
                }
                Console.WriteLine();
            }
            Console.Write("    ");
            for (int i = 0; i < chessboard.GetLength(0); i++)
            {
                Console.Write($"{(char)('A' + i)}     ");
            }
        }

        static void PutChessPieces(ChessPiece[,] chessboard)
        {
            ChessPieceType[] order = 
            {
                ChessPieceType.Rook, ChessPieceType.Knight, ChessPieceType.Bishop, ChessPieceType.Queen, //the layout of the chesspieces 

                ChessPieceType.King, ChessPieceType.Bishop, ChessPieceType.Knight, ChessPieceType.Rook
            };
            for (int column = 0; column < chessboard.GetLength(1); column++)
            {
                chessboard[1, column] = new ChessPiece
                {
                    type = ChessPieceType.Pawn,
                    color = ChessPieceColor.black
                };

                chessboard[6, column] = new ChessPiece
                {
                    type = ChessPieceType.Pawn,
                    color = ChessPieceColor.white
                };

                chessboard[0, column] = new ChessPiece
                {
                    type = order[column],
                    color = ChessPieceColor.black
                };
                chessboard[7, column] = new ChessPiece
                {
                    type = order[column],
                    color = ChessPieceColor.white
                };
            }
        }
        static void DisplayChessPiece(ChessPiece chessPiece)
        {
            if (chessPiece == null)
            {
                Console.Write("   ");
                return;
            }

            if (chessPiece.color == ChessPieceColor.white)
            {
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Black;
            }
            string symbol = "";

            switch (chessPiece.type) //could be done with if and else if but it gets anyoing
            {
                case ChessPieceType.Pawn:
                    symbol = "p";
                    break;
                case ChessPieceType.Rook:
                    symbol = "r";
                    break;
                case ChessPieceType.Knight:
                    symbol = "k";
                    break;
                case ChessPieceType.Bishop:
                    symbol = "b";
                    break;
                case ChessPieceType.King:
                    symbol = "K";
                    break;
                case ChessPieceType.Queen:
                    symbol = "Q";
                    break;
            }
            Console.Write($" {symbol} ");
        }

        static Position String2Position(string pos)
        {
            Position position = new Position();

            string[] positions = pos.Split(' ');

            int column = pos[0] - 'a';
            int row = 8 - int.Parse(pos[1].ToString());

            if (row < 0 || row > 7 || column < 0 || column > 7)
            {
                Console.WriteLine($"invalid position {pos}");
            }
            else
            {
                Console.WriteLine($"Move from {positions[0]} to {positions[1]}");
            }

            position.fieldRow = row;
            position.fieldCol = column;
            return position;
        }

        static void PlayChess(ChessPiece[,] chessboard)
        {
            do
            {
                Console.WriteLine();
                Console.WriteLine("Enter a move (e.g. a2 a3): ");
                string pos = Console.ReadLine();
                if (pos == "stop")
                {
                    break;
                }

                String2Position(pos);
            }
            while (true);
        }
    }
}
