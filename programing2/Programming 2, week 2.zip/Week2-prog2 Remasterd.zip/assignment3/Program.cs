﻿using System;

namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows = int.Parse(args[0]);
            int numberOfColumns = int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);
        }
        void Start(int numberOfRows, int numberOfColumns)
        {
            RegularCandies[,] playingField = new RegularCandies[numberOfRows, numberOfColumns];

            int[,] matrix = new int[numberOfRows, numberOfRows];

            InitCandies(matrix, playingField);

            DisplayCandies(matrix);
            Console.WriteLine();
            if (ScoreRowPresent(matrix))
            {
                Console.WriteLine("row score");

            }
            else
            {
                Console.WriteLine("no row score");

            }

            if (ScoreColumnPresent(matrix))
            {
                Console.WriteLine("column score");
            }
            else
            {
                Console.WriteLine("no column score");
            }
        }

        void InitCandies(int[,] matrix, RegularCandies[,] candies)
        {
            Random random = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = (int)(RegularCandies)random.Next(1, 7);
                }
            }
        }

        void DisplayCandies(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] == 1)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("#");
                        Console.ResetColor();
                    }
                    else if (matrix[i, j] == 2)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.Write("#");
                        Console.ResetColor();
                    }
                    else if (matrix[i, j] == 3)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("#");
                        Console.ResetColor();
                    }
                    else if (matrix[i, j] == 4)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write("#");
                        Console.ResetColor();
                    }
                    else if (matrix[i, j] == 5)
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write("#");
                        Console.ResetColor();
                    }
                    else if (matrix[i, j] == 6)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkMagenta;
                        Console.Write("#");
                        Console.ResetColor();
                    }
                }
                Console.WriteLine();
            }

        }

        bool ScoreRowPresent(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                int counter = 1;

                for (int j = 1; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j] == matrix[i, j - 1])
                    {
                        counter++;
                        if (counter == 3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                    }
                }
            }
            return false;
        }

        bool ScoreColumnPresent(int[,] matrix)
        {

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                int counter = 1;
                for (int j = 1; j < matrix.GetLength(1); j++)
                {
                    if (matrix[j, i] == matrix[j - 1, i])
                    {
                        counter++;
                        if (counter == 3)
                        {
                            return true;

                        }
                    }
                    else
                    {
                        counter = 1;

                    }
                }
            }
            return false;
        }
    }
}