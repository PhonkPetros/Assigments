﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3
{
    enum RegularCandies
    {
        JellyBean = 1, Lozenge, LemonDrop, GumSquare, LollipopHead, JujubeCluster
    }
}
