﻿using System.Data.Common;
using System.Security.Cryptography.X509Certificates;

namespace assignment2
{
    internal class Program
    {
        const int min = 1;
        const int max = 100;
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows = int.Parse(args[0]);
            int numberOfColumns = int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);
        }
        void Start(int numberOfRows, int numberOfColumns)
        {
            Position position = new Position();
            int[,] matrix = new int[numberOfRows, numberOfColumns];
            InitMatrixRandom(matrix, min, max);
            DisplayMatrix(matrix);

            Console.WriteLine("Enter a number to search for: ");
            int number = int.Parse(Console.ReadLine());

            position = SearchNumber(matrix, number);
            Console.WriteLine($"Number {number} is found (first) at position [{position.row}, {position.colum}]");
            position = SearchNumberBackwards(matrix, number);
            Console.WriteLine($"Number {number} is found (last) at position [{position.row}, {position.colum}]");
        }

        void InitMatrixRandom(int[,] matrix, int min, int max)
        {
            Random random = new Random();

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                    matrix[i, j] = random.Next(min, max);
            }
        }

        void DisplayMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j]} ");
                }
                Console.WriteLine("\n");
            }
        }

        Position SearchNumber(int[,] matrix, int number)
        {
            Position position = new Position();

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (number == matrix[i, j])
                    {
                        position.row = i;
                        position.colum = j;

                        return position;
                    }
                }
            }
            return position;

        }

        Position SearchNumberBackwards(int[,] matrix, int number)
        {
            Position position = new Position();

            for (int i = matrix.GetLength(0) - 1; i >= 0; i--)
            {
                for (int j = matrix.GetLength(1) - 1; j >= 0; j--)
                {
                    if (number == matrix[i, j])
                    {
                        position.row = i;
                        position.colum = j;

                        return position;
                    }
                }
            }
            return position;
        }
    }
}