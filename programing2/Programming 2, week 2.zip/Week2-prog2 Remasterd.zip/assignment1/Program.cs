﻿using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;

namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine("invalid number of arguments!");
                Console.WriteLine("usage: assignment[1-3] <nr of rows> <nr of columns>");
                return;
            }
            int numberOfRows = int.Parse(args[0]);
            int numberOfColumns = int.Parse(args[1]);
            Program myProgram = new Program();
            myProgram.Start(numberOfRows, numberOfColumns);
        }
        void Start(int numberOfRows, int numberOfColumns)
        {
            int[,] matrix = new int[numberOfRows, numberOfColumns];

            InitMatrix2D(matrix);
            DisplayMatrix(matrix);
            DisplayMatrixWithCross(matrix);
            InitMatrixLinear(matrix);
        }

        void InitMatrix2D(int[,] matrix)
        {
            int number = 1;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = number;
                    number++;
                }
            }
        }

        void DisplayMatrix(int[,] matrix)
        {
            for (var i = 0; i < matrix.GetLength(0); i++)
            {
                for (var j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j]} ");
                }
                Console.WriteLine("\n");
            }
        }
        void InitMatrixLinear(int[,] matrix)
        {
            for (int i = 0; i < matrix.Length; i++)
            {
                int r = i / matrix.GetLength(1);
                int c = i % matrix.GetLength(1);
                matrix[r, c] = (i + 1);
            }
        }

        void DisplayMatrixWithCross(int[,] matrix)
        {
            for (int rows = 0; rows < matrix.GetLength(0); rows++)
            {
                for (int columns = 0; columns < matrix.GetLength(1); columns++)
                {
                    Console.ResetColor();
                    if (rows == columns)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }
                    if ((rows + 1) + columns == matrix.GetLength(1))
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                    }
                    Console.Write($" {matrix[rows, columns]}");
                }
                Console.WriteLine();
            }
        }
    }
}